const router = require('express').Router();
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');
const { logAudit } = require('../middleware/audit');

router.use(verifyToken);

router.get('/', can('orders.view'), async (req, res, next) => {
  try {
    const { status, branch_id } = req.query;
    const conditions = [];
    const params = [];
    let p = 1;
    const branchFilter = ['admin','superadmin'].includes(req.user.role) ? branch_id : req.user.branch_id;
    if (branchFilter) { conditions.push(`o.branch_id = $${p++}`); params.push(branchFilter); }
    if (status)       { conditions.push(`o.status = $${p++}`);    params.push(status); }
    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await db.query(`
      SELECT o.*, t.number AS table_number,
        json_agg(json_build_object('name', mi.name, 'quantity', oi.quantity, 'price', oi.unit_price)) AS items
      FROM orders o
      LEFT JOIN tables t       ON t.id = o.table_id
      LEFT JOIN order_items oi ON oi.order_id = o.id
      LEFT JOIN menu_items mi  ON mi.id = oi.menu_item_id
      ${where}
      GROUP BY o.id, t.number
      ORDER BY o.created_at DESC
      LIMIT 100
    `, params);
    res.json(rows);
  } catch (err) { next(err); }
});

router.get('/:id', can('orders.view'), async (req, res, next) => {
  try {
    const { rows } = await db.query(`
      SELECT o.*,
        json_agg(json_build_object('name', mi.name, 'quantity', oi.quantity, 'price', oi.unit_price)) AS items
      FROM orders o
      LEFT JOIN order_items oi ON oi.order_id = o.id
      LEFT JOIN menu_items mi  ON mi.id = oi.menu_item_id
      WHERE o.id = $1 GROUP BY o.id
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Order not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

router.post('/', can('orders.create'), async (req, res, next) => {
  const client = await db.getClient();
  try {
    await client.query('BEGIN');
    const { branch_id, table_id, order_type, items, notes, customer_name, customer_phone } = req.body;
    if (!items?.length) return res.status(400).json({ error: 'Items required' });

    let total = 0;
    const resolved = [];
    for (const item of items) {
      const { rows } = await client.query(
        'SELECT id, name, price, is_available FROM menu_items WHERE id = $1',
        [item.menu_item_id]
      );
      if (!rows.length || !rows[0].is_available) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: `Item ${item.menu_item_id} not available` });
      }
      total += rows[0].price * item.quantity;
      resolved.push({ ...item, unit_price: rows[0].price, name: rows[0].name });
    }

    const { rows: [order] } = await client.query(
      "INSERT INTO orders (branch_id, table_id, order_type, total, status, notes, customer_name, customer_phone, created_by) VALUES ($1,$2,$3,$4,'new',$5,$6,$7,$8) RETURNING *",
      [branch_id, table_id || null, order_type, total, notes || '', customer_name || '', customer_phone || '', req.user.id]
    );

    for (const item of resolved) {
      await client.query(
        'INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price, notes) VALUES ($1,$2,$3,$4,$5)',
        [order.id, item.menu_item_id, item.quantity, item.unit_price, item.notes || '']
      );
    }

    await client.query('COMMIT');

    const io = req.app.get('io');
    io.to(`branch_${branch_id}`).emit('new_order', { id: order.id, order_type, total });

    logAudit(req, 'ORDER_CREATED', { orderId: order.id, total });
    res.status(201).json({ ...order, items: resolved });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally { client.release(); }
});

router.patch('/:id/status', can('orders.update_status'), async (req, res, next) => {
  try {
    const { status } = req.body;
    const valid = ['new','preparing','ready','delivered','cancelled'];
    if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const { rows: [order] } = await db.query(
      'UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [status, req.params.id]
    );
    if (!order) return res.status(404).json({ error: 'Order not found' });
    req.app.get('io').to(`branch_${order.branch_id}`).emit('order_updated', { id: order.id, status });
    logAudit(req, 'ORDER_STATUS_CHANGED', { orderId: order.id, status });
    res.json(order);
  } catch (err) { next(err); }
});

module.exports = router;

const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');
const { logAudit } = require('../middleware/audit');

router.use(verifyToken);

router.get('/', can('staff.*'), async (req, res, next) => {
  try {
    const branchFilter = ['admin','superadmin'].includes(req.user.role) ? req.query.branch_id : req.user.branch_id;
    const params = [];
    let where = '';
    if (branchFilter) { where = 'WHERE s.branch_id = $1'; params.push(branchFilter); }
    const { rows } = await db.query(`
      SELECT s.id, s.name, s.email, s.phone, s.role, s.branch_id, s.is_active, s.last_seen, b.name AS branch_name
      FROM staff s LEFT JOIN branches b ON b.id = s.branch_id
      ${where} ORDER BY s.name
    `, params);
    res.json(rows);
  } catch (err) { next(err); }
});

router.post('/', can('staff.*'), async (req, res, next) => {
  try {
    const { branch_id, name, email, phone, role, password } = req.body;
    if (!name || !email || !password || !role) return res.status(400).json({ error: 'name, email, password, role required' });
    const { rows: ex } = await db.query('SELECT id FROM staff WHERE email = $1', [email.toLowerCase()]);
    if (ex.length) return res.status(409).json({ error: 'Email already exists' });
    const hash = await bcrypt.hash(password, 12);
    const { rows: [staff] } = await db.query(
      'INSERT INTO staff (branch_id, name, email, phone, role, password_hash) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, name, email, role, branch_id',
      [branch_id || null, name, email.toLowerCase(), phone || '', role, hash]
    );
    logAudit(req, 'STAFF_CREATED', { staffId: staff.id, name, role });
    res.status(201).json(staff);
  } catch (err) { next(err); }
});

router.put('/:id', can('staff.*'), async (req, res, next) => {
  try {
    const { name, phone, role, branch_id } = req.body;
    const { rows: [staff] } = await db.query(
      'UPDATE staff SET name=$1, phone=$2, role=$3, branch_id=$4 WHERE id=$5 RETURNING id, name, role',
      [name, phone || '', role, branch_id || null, req.params.id]
    );
    if (!staff) return res.status(404).json({ error: 'Not found' });
    res.json(staff);
  } catch (err) { next(err); }
});

router.patch('/:id/deactivate', can('staff.*'), async (req, res, next) => {
  try {
    if (String(req.params.id) === String(req.user.id)) return res.status(400).json({ error: 'Cannot deactivate yourself' });
    const { rows: [staff] } = await db.query('UPDATE staff SET is_active=false WHERE id=$1 RETURNING id, name', [req.params.id]);
    if (!staff) return res.status(404).json({ error: 'Not found' });
    await db.query('DELETE FROM refresh_tokens WHERE user_id=$1', [req.params.id]);
    logAudit(req, 'STAFF_DEACTIVATED', { staffId: staff.id });
    res.json({ message: 'Deactivated', staff });
  } catch (err) { next(err); }
});

module.exports = router;

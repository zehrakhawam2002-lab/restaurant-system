const router = require('express').Router();
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');
const { logAudit } = require('../middleware/audit');

router.use(verifyToken);

router.get('/alerts', can('inventory.*'), async (req, res, next) => {
  try {
    const branchId = ['admin','superadmin'].includes(req.user.role) ? req.query.branch_id : req.user.branch_id;
    const params = [];
    let where = 'WHERE quantity <= min_quantity';
    if (branchId) { where += ' AND branch_id = $1'; params.push(branchId); }
    const { rows } = await db.query(`SELECT * FROM inventory ${where} ORDER BY quantity`, params);
    res.json(rows);
  } catch (err) { next(err); }
});

router.get('/', can('inventory.*'), async (req, res, next) => {
  try {
    const branchFilter = ['admin','superadmin'].includes(req.user.role) ? req.query.branch_id : req.user.branch_id;
    const params = [];
    let where = '';
    if (branchFilter) { where = 'WHERE branch_id = $1'; params.push(branchFilter); }
    const { rows } = await db.query(`SELECT * FROM inventory ${where} ORDER BY name`, params);
    res.json(rows);
  } catch (err) { next(err); }
});

router.post('/', can('inventory.*'), async (req, res, next) => {
  try {
    const { branch_id, name, unit, quantity, min_quantity, cost_per_unit, supplier } = req.body;
    if (!branch_id || !name) return res.status(400).json({ error: 'branch_id and name required' });
    const { rows: [item] } = await db.query(
      'INSERT INTO inventory (branch_id, name, unit, quantity, min_quantity, cost_per_unit, supplier) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
      [branch_id, name, unit || '', quantity || 0, min_quantity || 0, cost_per_unit || null, supplier || '']
    );
    logAudit(req, 'INVENTORY_CREATED', { itemId: item.id, name });
    res.status(201).json(item);
  } catch (err) { next(err); }
});

router.patch('/:id', can('inventory.*'), async (req, res, next) => {
  try {
    const { quantity } = req.body;
    if (quantity === undefined) return res.status(400).json({ error: 'quantity required' });
    const { rows: [item] } = await db.query(
      'UPDATE inventory SET quantity=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [quantity, req.params.id]
    );
    if (!item) return res.status(404).json({ error: 'Not found' });
    res.json(item);
  } catch (err) { next(err); }
});

router.delete('/:id', can('inventory.*'), async (req, res, next) => {
  try {
    const { rows: [item] } = await db.query('DELETE FROM inventory WHERE id=$1 RETURNING id, name', [req.params.id]);
    if (!item) return res.status(404).json({ error: 'Not found' });
    logAudit(req, 'INVENTORY_DELETED', { itemId: item.id });
    res.json({ message: 'Deleted' });
  } catch (err) { next(err); }
});

module.exports = router;

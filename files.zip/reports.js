const router = require('express').Router();
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');

router.use(verifyToken);

router.get('/summary', can('reports.view'), async (req, res, next) => {
  try {
    const branchFilter = ['admin','superadmin'].includes(req.user.role) ? req.query.branch_id : req.user.branch_id;
    const params = [];
    const conditions = ["status NOT IN ('cancelled')"];
    let p = 1;
    if (branchFilter) { conditions.push(`branch_id = $${p++}`); params.push(branchFilter); }
    if (req.query.from) { conditions.push(`created_at >= $${p++}`); params.push(req.query.from); }
    if (req.query.to)   { conditions.push(`created_at <= $${p++}`); params.push(req.query.to); }
    const where = 'WHERE ' + conditions.join(' AND ');
    const { rows: [summary] } = await db.query(
      `SELECT COUNT(*)::int AS total_orders, SUM(total) AS total_revenue, AVG(total) AS avg_order_value FROM orders ${where}`,
      params
    );
    res.json(summary);
  } catch (err) { next(err); }
});

router.get('/daily', can('reports.view'), async (req, res, next) => {
  try {
    const days = parseInt(req.query.days) || 7;
    const branchFilter = ['admin','superadmin'].includes(req.user.role) ? req.query.branch_id : req.user.branch_id;
    const params = [days];
    let where = `WHERE status NOT IN ('cancelled') AND created_at >= NOW() - ($1 || ' days')::INTERVAL`;
    if (branchFilter) { where += ` AND branch_id = $2`; params.push(branchFilter); }
    const { rows } = await db.query(
      `SELECT DATE(created_at) AS date, COUNT(*)::int AS orders, SUM(total) AS revenue FROM orders ${where} GROUP BY DATE(created_at) ORDER BY date DESC`,
      params
    );
    res.json(rows);
  } catch (err) { next(err); }
});

module.exports = router;

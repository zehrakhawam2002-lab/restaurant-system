const jwt = require('jsonwebtoken');
const db  = require('../db');

const PERMISSIONS = {
  superadmin: ['*'],
  admin:      ['orders.*','menu.*','staff.*','reports.*','inventory.*','tables.*','branches.view'],
  manager:    ['orders.*','menu.view','menu.edit','inventory.*','tables.*','reports.view'],
  cashier:    ['orders.create','orders.view','menu.view','tables.view'],
  kitchen:    ['orders.view','orders.update_status'],
  waiter:     ['orders.create','orders.view','tables.view','menu.view'],
};

const verifyToken = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    if (!authHeader?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }
    const token = authHeader.split(' ')[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET, {
        algorithms: ['HS256'],
        issuer: 'restaurant-os',
        audience: 'restaurant-api',
      });
    } catch (jwtErr) {
      if (jwtErr.name === 'TokenExpiredError') {
        return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
      }
      return res.status(401).json({ error: 'Invalid token' });
    }
    const { rows } = await db.query(
      'SELECT id, name, role, branch_id, is_active FROM staff WHERE id = $1',
      [decoded.sub]
    );
    if (!rows.length || !rows[0].is_active) {
      return res.status(401).json({ error: 'User not found or deactivated' });
    }
    req.user = { ...decoded, ...rows[0] };
    next();
  } catch (err) { next(err); }
};

const require2FA = (req, res, next) => {
  if (req.user?.twofa_verified !== true) {
    return res.status(403).json({ error: '2FA required', code: '2FA_REQUIRED' });
  }
  next();
};

const can = (permission) => (req, res, next) => {
  const role  = req.user?.role;
  const perms = PERMISSIONS[role] || [];
  const allowed =
    perms.includes('*') ||
    perms.includes(permission) ||
    perms.includes(permission.split('.')[0] + '.*');
  if (!allowed) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
};

const sameBranch = (req, res, next) => {
  const { role, branch_id } = req.user;
  if (role === 'superadmin' || role === 'admin') return next();
  const reqBranch = req.params.branchId || req.body.branch_id || req.query.branch_id;
  if (reqBranch && String(reqBranch) !== String(branch_id)) {
    return res.status(403).json({ error: 'Cross-branch access denied' });
  }
  next();
};

module.exports = { verifyToken, require2FA, can, sameBranch };

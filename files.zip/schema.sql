-- ════════════════════════════════════════════════════════
--  RestaurantOS — PostgreSQL Schema
--  قاعدة البيانات الكاملة مع الفهارس والأمان
-- ════════════════════════════════════════════════════════

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── BRANCHES (الفروع)
CREATE TABLE branches (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  address     TEXT,
  phone       VARCHAR(20),
  is_active   BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── STAFF (الموظفون)
CREATE TABLE staff (
  id                   SERIAL PRIMARY KEY,
  branch_id            INTEGER REFERENCES branches(id),
  name                 VARCHAR(100) NOT NULL,
  email                VARCHAR(150) UNIQUE NOT NULL,
  phone                VARCHAR(20),
  password_hash        TEXT NOT NULL,
  role                 VARCHAR(20) NOT NULL CHECK (role IN ('superadmin','admin','manager','cashier','kitchen','waiter')),
  totp_secret          TEXT,                        -- 2FA secret (مشفّر)
  totp_secret_pending  TEXT,                        -- مؤقت أثناء الإعداد
  is_active            BOOLEAN DEFAULT true,
  last_seen            TIMESTAMPTZ,
  password_changed_at  TIMESTAMPTZ DEFAULT NOW(),
  created_at           TIMESTAMPTZ DEFAULT NOW()
);

-- ── REFRESH TOKENS
CREATE TABLE refresh_tokens (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER REFERENCES staff(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL,
  ip          VARCHAR(50),
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ── FAILED LOGINS (لمراقبة Brute Force)
CREATE TABLE failed_logins (
  id           SERIAL PRIMARY KEY,
  email        VARCHAR(150),
  ip           VARCHAR(50),
  attempted_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── TABLES (طاولات المطعم)
CREATE TABLE tables (
  id        SERIAL PRIMARY KEY,
  branch_id INTEGER REFERENCES branches(id) NOT NULL,
  number    VARCHAR(10) NOT NULL,
  capacity  SMALLINT DEFAULT 4,
  status    VARCHAR(20) DEFAULT 'free' CHECK (status IN ('free','occupied','reserved','cleaning')),
  UNIQUE(branch_id, number)
);

-- ── MENU CATEGORIES
CREATE TABLE menu_categories (
  id        SERIAL PRIMARY KEY,
  branch_id INTEGER REFERENCES branches(id),  -- NULL = لكل الفروع
  name      VARCHAR(100) NOT NULL,
  sort_order SMALLINT DEFAULT 0
);

-- ── MENU ITEMS
CREATE TABLE menu_items (
  id           SERIAL PRIMARY KEY,
  branch_id    INTEGER REFERENCES branches(id),  -- NULL = لكل الفروع
  category_id  INTEGER REFERENCES menu_categories(id),
  name         VARCHAR(150) NOT NULL,
  description  TEXT,
  price        NUMERIC(10,2) NOT NULL CHECK (price >= 0),
  image_url    TEXT,
  is_available BOOLEAN DEFAULT true,
  is_deleted   BOOLEAN DEFAULT false,           -- Soft delete
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── ORDERS
CREATE TABLE orders (
  id              SERIAL PRIMARY KEY,
  branch_id       INTEGER REFERENCES branches(id) NOT NULL,
  table_id        INTEGER REFERENCES tables(id),
  created_by      INTEGER REFERENCES staff(id),
  order_type      VARCHAR(20) NOT NULL CHECK (order_type IN ('dine_in','delivery','pickup')),
  status          VARCHAR(20) DEFAULT 'new' CHECK (status IN ('new','preparing','ready','delivered','cancelled')),
  total           NUMERIC(12,2) NOT NULL,
  customer_name   VARCHAR(100),
  customer_phone  VARCHAR(20),
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── ORDER ITEMS
CREATE TABLE order_items (
  id           SERIAL PRIMARY KEY,
  order_id     INTEGER REFERENCES orders(id) ON DELETE CASCADE,
  menu_item_id INTEGER REFERENCES menu_items(id),
  quantity     SMALLINT NOT NULL CHECK (quantity > 0),
  unit_price   NUMERIC(10,2) NOT NULL,
  notes        TEXT
);

-- ── INVENTORY (المخزون)
CREATE TABLE inventory (
  id           SERIAL PRIMARY KEY,
  branch_id    INTEGER REFERENCES branches(id) NOT NULL,
  name         VARCHAR(150) NOT NULL,
  unit         VARCHAR(20),           -- كغ, لتر, قطعة ...
  quantity     NUMERIC(10,3) DEFAULT 0,
  min_quantity NUMERIC(10,3) DEFAULT 0,  -- حد التنبيه
  cost_per_unit NUMERIC(10,2),
  supplier     VARCHAR(150),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── AUDIT LOG (سجل كل العمليات للأمان)
CREATE TABLE audit_logs (
  id         BIGSERIAL PRIMARY KEY,
  user_id    INTEGER REFERENCES staff(id),
  user_name  VARCHAR(100),
  role       VARCHAR(20),
  action     VARCHAR(100) NOT NULL,    -- مثال: ORDER_CREATED, LOGIN_FAILED
  entity     VARCHAR(50),
  entity_id  INTEGER,
  details    JSONB,
  ip         VARCHAR(50),
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ════════════════════════════════
--  INDEXES (لسرعة الاستعلامات)
-- ════════════════════════════════

CREATE INDEX idx_orders_branch_status  ON orders(branch_id, status);
CREATE INDEX idx_orders_created_at     ON orders(created_at DESC);
CREATE INDEX idx_audit_user_id         ON audit_logs(user_id);
CREATE INDEX idx_audit_created_at      ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_action          ON audit_logs(action);
CREATE INDEX idx_menu_items_branch     ON menu_items(branch_id) WHERE NOT is_deleted;
CREATE INDEX idx_inventory_branch      ON inventory(branch_id);
CREATE INDEX idx_refresh_tokens_user   ON refresh_tokens(user_id);
CREATE INDEX idx_failed_logins_email   ON failed_logins(email, attempted_at);

-- ════════════════════════════════
--  ROW LEVEL SECURITY (RLS)
--  حماية إضافية على مستوى الداتابيس
-- ════════════════════════════════

ALTER TABLE orders     ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory  ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- فقط الـ app_user يقدر يقرأ أوامر فرعه
-- (الـ superadmin_role يشوف الكل)
CREATE POLICY orders_branch_isolation ON orders
  USING (
    current_setting('app.current_branch_id', true)::INTEGER IS NULL
    OR branch_id = current_setting('app.current_branch_id', true)::INTEGER
  );

-- ════════════════════════════════
--  TRIGGERS (للـ updated_at التلقائي)
-- ════════════════════════════════

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_menu_items_updated_at
  BEFORE UPDATE ON menu_items
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ════════════════════════════════
--  SEED DATA (بيانات أولية)
-- ════════════════════════════════

-- فرع رئيسي
INSERT INTO branches (name, address, phone) VALUES
  ('فرع الكرادة', 'بغداد — شارع الكرادة الداخلية', '+964 770 111 1111'),
  ('فرع المنصور', 'بغداد — شارع 14 رمضان', '+964 770 222 2222'),
  ('فرع زيونة',   'بغداد — زيونة الجديدة',       '+964 770 333 3333');

-- مستخدم superadmin (كلمة المرور: Admin@12345 مشفّرة)
INSERT INTO staff (branch_id, name, email, password_hash, role) VALUES
  (1, 'أحمد الكريمي', 'admin@restaurant.iq',
   '$2b$12$examplehashedpassword_replace_in_production', 'superadmin');

-- فئات المنيو
INSERT INTO menu_categories (name, sort_order) VALUES
  ('وجبات رئيسية', 1), ('مقبلات', 2), ('مشروبات', 3), ('حلويات', 4);

-- أصناف المنيو
INSERT INTO menu_items (category_id, name, price) VALUES
  (1, 'برغر كلاسيك',    12500),
  (1, 'دجاج مشوي',      22000),
  (1, 'بيتزا مارجريتا', 18000),
  (1, 'ستيك وسط',       35000),
  (2, 'سلطة سيزر',       9000),
  (3, 'عصير طازج',       6500),
  (3, 'قهوة تركية',      4000),
  (4, 'كيك شوكولاتة',    8500);

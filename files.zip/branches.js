const router = require('express').Router();
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');
const { logAudit } = require('../middleware/audit');

router.use(verifyToken);

router.get('/', can('branches.view'), async (req, res, next) => {
  try {
    const { rows } = await db.query('SELECT * FROM branches WHERE is_active=true ORDER BY name');
    res.json(rows);
  } catch (err) { next(err); }
});

router.post('/', can('admin'), async (req, res, next) => {
  try {
    const { name, address, phone } = req.body;
    if (!name) return res.status(400).json({ error: 'Name required' });
    const { rows: [branch] } = await db.query(
      'INSERT INTO branches (name, address, phone) VALUES ($1,$2,$3) RETURNING *',
      [name, address || '', phone || '']
    );
    logAudit(req, 'BRANCH_CREATED', { branchId: branch.id, name });
    res.status(201).json(branch);
  } catch (err) { next(err); }
});

router.put('/:id', can('admin'), async (req, res, next) => {
  try {
    const { name, address, phone } = req.body;
    const { rows: [branch] } = await db.query(
      'UPDATE branches SET name=$1, address=$2, phone=$3 WHERE id=$4 RETURNING *',
      [name, address || '', phone || '', req.params.id]
    );
    if (!branch) return res.status(404).json({ error: 'Not found' });
    res.json(branch);
  } catch (err) { next(err); }
});

module.exports = router;

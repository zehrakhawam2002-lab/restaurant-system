const router = require('express').Router();
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');

router.use(verifyToken);

router.get('/', can('tables.view'), async (req, res, next) => {
  try {
    const branchFilter = ['admin','superadmin'].includes(req.user.role) ? req.query.branch_id : req.user.branch_id;
    const params = [];
    let where = '';
    if (branchFilter) { where = 'WHERE branch_id = $1'; params.push(branchFilter); }
    const { rows } = await db.query(`SELECT * FROM tables ${where} ORDER BY number`, params);
    res.json(rows);
  } catch (err) { next(err); }
});

router.post('/', can('manager'), async (req, res, next) => {
  try {
    const { branch_id, number, capacity } = req.body;
    if (!branch_id || !number) return res.status(400).json({ error: 'branch_id and number required' });
    const { rows: [table] } = await db.query(
      'INSERT INTO tables (branch_id, number, capacity) VALUES ($1,$2,$3) RETURNING *',
      [branch_id, number, capacity || 4]
    );
    res.status(201).json(table);
  } catch (err) { next(err); }
});

router.patch('/:id/status', can('tables.view'), async (req, res, next) => {
  try {
    const { status } = req.body;
    const valid = ['free','occupied','reserved','cleaning'];
    if (!valid.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const { rows: [table] } = await db.query(
      'UPDATE tables SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]
    );
    if (!table) return res.status(404).json({ error: 'Not found' });
    res.json(table);
  } catch (err) { next(err); }
});

module.exports = router;

const router = require('express').Router();
const db     = require('../db');
const { verifyToken, can } = require('../middleware/auth');
const { logAudit } = require('../middleware/audit');

router.use(verifyToken);

router.get('/categories', async (req, res, next) => {
  try {
    const { rows } = await db.query('SELECT * FROM menu_categories ORDER BY sort_order');
    res.json(rows);
  } catch (err) { next(err); }
});

router.get('/', async (req, res, next) => {
  try {
    const { branch_id, category_id } = req.query;
    const conditions = ['mi.is_deleted = false'];
    const params = [];
    let p = 1;
    if (branch_id)   { conditions.push(`(mi.branch_id = $${p++} OR mi.branch_id IS NULL)`); params.push(branch_id); }
    if (category_id) { conditions.push(`mi.category_id = $${p++}`); params.push(category_id); }
    const { rows } = await db.query(`
      SELECT mi.*, mc.name AS category_name FROM menu_items mi
      LEFT JOIN menu_categories mc ON mc.id = mi.category_id
      WHERE ${conditions.join(' AND ')}
      ORDER BY mc.sort_order, mi.name
    `, params);
    res.json(rows);
  } catch (err) { next(err); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const { rows } = await db.query(
      'SELECT mi.*, mc.name AS category_name FROM menu_items mi LEFT JOIN menu_categories mc ON mc.id = mi.category_id WHERE mi.id = $1 AND mi.is_deleted = false',
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Item not found' });
    res.json(rows[0]);
  } catch (err) { next(err); }
});

router.post('/', can('menu.edit'), async (req, res, next) => {
  try {
    const { category_id, branch_id, name, description, price, is_available = true } = req.body;
    if (!name || price === undefined) return res.status(400).json({ error: 'name and price required' });
    const { rows: [item] } = await db.query(
      'INSERT INTO menu_items (category_id, branch_id, name, description, price, is_available) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [category_id, branch_id || null, name, description || '', price, is_available]
    );
    logAudit(req, 'MENU_ITEM_CREATED', { itemId: item.id, name });
    res.status(201).json(item);
  } catch (err) { next(err); }
});

router.put('/:id', can('menu.edit'), async (req, res, next) => {
  try {
    const { category_id, branch_id, name, description, price, is_available } = req.body;
    const { rows: [item] } = await db.query(
      'UPDATE menu_items SET category_id=$1, branch_id=$2, name=$3, description=$4, price=$5, is_available=$6, updated_at=NOW() WHERE id=$7 AND is_deleted=false RETURNING *',
      [category_id, branch_id || null, name, description || '', price, is_available, req.params.id]
    );
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json(item);
  } catch (err) { next(err); }
});

router.patch('/:id/availability', can('menu.edit'), async (req, res, next) => {
  try {
    const { rows: [item] } = await db.query(
      'UPDATE menu_items SET is_available=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [req.body.is_available, req.params.id]
    );
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json(item);
  } catch (err) { next(err); }
});

router.delete('/:id', can('menu.edit'), async (req, res, next) => {
  try {
    const { rows: [item] } = await db.query(
      'UPDATE menu_items SET is_deleted=true WHERE id=$1 RETURNING id, name', [req.params.id]
    );
    if (!item) return res.status(404).json({ error: 'Item not found' });
    logAudit(req, 'MENU_ITEM_DELETED', { itemId: item.id });
    res.json({ message: 'Deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
